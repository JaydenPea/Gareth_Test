Gareth Elie's Recipe Program:
Welcome to the repository for Gareth Elie's Recipe Program. This is a console-based application developed in C# that provides a simple and interactive way to manage your recipes. With this program, you can enter recipe details, display them, scale them according to your needs, reset quantities, and clear all data.

Table of Contents
Getting Started
Prerequisites
Installing
Running the Program
Updates in Part 2
Contributing
License
Getting Started
These instructions will guide you on how to get a copy of this project up and running on your local machine for development and testing purposes.

Prerequisites
Before you begin, ensure you have met the following requirements:

You have installed the latest version of .NET Core SDK.
You have a Windows, Linux, or Mac machine.
You have a text editor like VS Code or an IDE like Visual Studio installed.
Installing
To install Gareth Elie's Recipe Program, follow these steps:

Clone the repository to your local machine using the following command in your terminal:
bash
Copy code
git clone https://github.com/VCNMB/VCNMB-PROG6221-2024-POE--garethlelie.git
Navigate to the directory of the cloned repository:
bash
Copy code
cd VCNMB-PROG6221-2024-POE--garethlelie
Running the Program
To run Gareth Elie’s Recipe Program, follow these steps:

Open a terminal or command prompt.
Navigate to the project directory if you haven't already.
Run the following command to compile and run the program:
bash
Copy code
dotnet run
You should now see the program running in your terminal or command prompt, displaying the main menu where you can manage your recipes.
Updates in Part 2
In Part 2 of this project, several updates and enhancements have been made:

Updated Features
Changed color of code to green.
Unit Tests: Added comprehensive unit tests for the Recipe class to ensure reliability and correctness of the functionalities.
CalculateTotalCalories_SingleIngredient_CorrectTotal: Verifies the total calories for a single ingredient.
CalculateTotalCalories_MultipleIngredients_CorrectTotal: Verifies the total calories for multiple ingredients.
CalculateTotalCalories_NoIngredients_ZeroTotal: Ensures the total calories is zero when no ingredients are present.
Implementation Details
Unit Testing Framework: The project now includes a test suite using Microsoft.VisualStudio.TestTools.UnitTesting.
Test Methods: Various test methods have been implemented to test different aspects of the Recipe class functionality.
Test Classes: Organized test methods into the RecipeTests class to validate the behavior of the Recipe class.
How to Run the Tests
To run the unit tests, follow these steps:

Open a terminal or command prompt.
Navigate to the project directory.
Run the following command to execute the tests:
bash
Copy code
dotnet test
This will run all the unit tests and display the results in the terminal or command prompt.
Contributing
To contribute to this project, please follow these steps:

Fork the repository.
Create a new branch (git checkout -b feature-branch).
Make your changes and commit them (git commit -m 'Add some feature').
Push to the branch (git push origin feature-branch).
Create a new Pull Request.
Please read CONTRIBUTING.md for details on our code of conduct and the process for submitting pull requests to us.

License
This project is licensed under the MIT License - see the LICENSE.md file for details.
