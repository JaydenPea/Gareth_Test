﻿using garethuse.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace garethuse
{
    public partial class Form1 : Form
    {
        //Initialize to save List to hold recipes and ingredients
        private List<Recipes> recipeList = new List<Recipes>();
        private System.Windows.Forms.ListBox listBoxRecipes;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // Populate ListBox with recipe names
        private void PopulateRecipeList()
        {
            this.listBoxRecipes.Visible = true;
            foreach (Recipes recipe in recipeList)
            {
                listBoxRecipes.Items.Add(recipe.name);
            }
        }

        //Dropdown list to determine logic
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = this.comboBox1.SelectedItem.ToString();
            OnClick(selectedItem);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            //if input is not empty lets move onto step 2
            if (!string.IsNullOrEmpty(this.textBox1.Text))
            {
                this.label2.Visible = true;
                this.label2.Text = "Enter the number of ingredients:";
                this.numericUpDown1.Visible = true;

            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int ingredientCount = (int)this.numericUpDown1.Value;
            if (ingredientCount >= 1)
            {
                
                // Create questions for each ingredient and save them for each individual ingrdient added.
                for (int i = 0; i < ingredientCount; i++)
                {
                    this.label3.Visible = true;
                    this.label3.Text = "Enter name of ingredient:";
                    this.maskedTextBox2.Visible = true;

                    this.label4.Visible = true;
                    this.label4.Text = "Enter quantity of ingredient:";
                    this.numericUpDown2.Visible = true;

                   
                }
            }
            else
            {
                // Hide label and maskedTextBox2 if ingredient count is 0
                this.label3.Visible = false;
                this.maskedTextBox2.Visible = false;
                
            }
        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (!string.IsNullOrEmpty(maskedTextBox2.Text))
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            // Create a new recipe instance
            Recipes newRecipe = new Recipes
            {
                name = this.textBox1.Text
            };

            // Add ingredients to the recipe
            int ingredientCount = (int)this.numericUpDown1.Value;
            for (int i = 0; i < ingredientCount; i++)
            {
                Ingredients ingredient = new Ingredients
                {
                    ingredientName = this.maskedTextBox2.Text,
                    quantity = this.numericUpDown2.Value,
                    measurement = "grams" // You can adjust this as needed based on your UI
                };

                newRecipe.ingredients.Add(ingredient);
            }

            // Add the recipe to the list
            recipeList.Add(newRecipe);

            //clear UI after adding a recipe to add another if wanted
            ClearUI();

        }

        private void ClearUI()
        {
            this.numericUpDown1.Enabled = false;
            this.textBox1.Enabled = false;

            this.maskedTextBox2.Text = string.Empty;
            this.numericUpDown2.Value = 0;
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown2.Value > 0)
            {
                this.button1.Visible = true;
                this.button1.Text = "Add new igredient to recipe";
            }
        }
    }
}
