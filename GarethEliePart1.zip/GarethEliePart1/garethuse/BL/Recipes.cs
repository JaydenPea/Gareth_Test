﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace garethuse.BL
{
    public class Recipes
    {
        public string name { get; set; } = string.Empty; //recipe name
        public List<Ingredients> ingredients { get; set; }= new List<Ingredients>(); //one recipe can have many ingredients.
         
    }

    public class Ingredients
    {
        public string ingredientName { get; set; } = string.Empty;
        public decimal quantity { get; set; } = 0;
        public string measurement {  get; set; } = string.Empty;
    }
}
