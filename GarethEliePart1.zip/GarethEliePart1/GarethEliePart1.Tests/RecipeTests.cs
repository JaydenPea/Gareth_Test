﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GarethEliePart1;

namespace GarethEliePart1.Tests
{
    [TestClass]
    public class RecipeTests
    {
        [TestMethod]
        public void CalculateTotalCalories_ReturnCorrectTotal_SingleIngredient()
        {
            // Arrange: Create a new Recipe object and add a single ingredient
            var recipe = new Recipe();
            var sugar = new Ingredient("Sugar", 250, "grams", 200, "Carbohydrates");
            recipe.AddIngredient(sugar);

            // Act: Calculate the total calories of the recipe
            var totalCalories = recipe.CalculateTotalCalories();

            // Assert: Verify that the total calories is correct
            Assert.AreEqual(390, totalCalories);
        }

        [TestMethod]
      

        public void CalculateTotalCalorie_ReturnZero_NoIngredients()
        {
            // Arrange: Create a new Recipe object with no ingredients
            var recipe = new Recipe();

            // Act: Calculate the total calories of the recipe
            var totalCalories = recipe.CalculateTotalCalories();

            // Assert: Verify that the total calories is zero
            Assert.AreEqual(0, totalCalories);
        }
    }
}