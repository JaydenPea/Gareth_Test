﻿using System.Text;

namespace GarethEliePart1
{
    // Main class of the program
    class Program
    {
        // Main method, entry point for my the program
        static void Main(string[] args)
        {
            // Change the console text color to blue
            Console.ForegroundColor = ConsoleColor.Blue;

            //(educative, 2024)
            // Create an instance of the RecipeBook class
            RecipeBook myRecipeBook = new RecipeBook();

            // Subscribe to the high-calorie warning event
            myRecipeBook.HighCalorieWarning += HandleHighCalorieWarning;// test

            // Variable to keep the application running
            //(stackoverflow, 2020)
            bool isRunning = true;

            // Loop for the Main Application
            //(stackoverflow, 2020)
            while (isRunning)
            {
                //(wellSB, 2019)
                // Displaying menu options
                Console.WriteLine("Select an option:");
                Console.WriteLine("1 - Input Recipe Details");
                Console.WriteLine("2 - Show Recipe");
                Console.WriteLine("3 - Adjust Recipe Size");
                Console.WriteLine("4 - Reset Ingredient Quantities");
                Console.WriteLine("5 - Remove All Information");
                Console.WriteLine("6 - List All Recipes");
                Console.WriteLine("7 - Quit Application");
                Console.Write("Your choice: ");

                //(cheqq,2022)
                //(w3schools, 2023)
                // Read user's choice
                int userChoice;
                if (!int.TryParse(Console.ReadLine(), out userChoice))
                {
                    Console.WriteLine("Invalid input. Please enter a number from 1 to 7.");
                    continue;
                }

                // Execute user's choice
                switch (userChoice)
                {
                    case 1:
                        myRecipeBook.InputRecipe();
                        break;
                    case 2:
                        myRecipeBook.ShowRecipe();
                        break;
                    case 3:
                        myRecipeBook.ScaleRecipe();
                        break;
                    case 4:
                        myRecipeBook.ResetQuantities();
                        break;
                    case 5:
                        myRecipeBook.RemoveAllInfo();
                        break;
                    case 6:
                        myRecipeBook.ListRecipes();
                        break;
                    case 7:
                        isRunning = false; // Exit the loop to end the program
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a number from 1 to 7.");
                        break;
                }
            }
        }

        //(stackoverflow, 2020)
        // Event handler for high-calorie warning
        static void HandleHighCalorieWarning(string message)
        {
            Console.WriteLine(message);
        }
    }
}

//References: 
//w3schools. (n.d.).C# Switch Statements. C# switch. https://www.w3schools.com/cs/cs_switch.php (Accessed 16 April 2024)
//stackoverflow. (2020, September 1). Using boolean values in C. https://stackoverflow.com/questions/1921539/using-boolean-values-in-c (Accessed 16 April 2024)
//wellSB. (2019, May 27). Create a menu in C# console application. C# Tutorials Blog. https://wellsb.com/csharp/beginners/create-menu-csharp-console-application (Accessed 16 April 2024)
//educative. (n.d.). How to create instances of a class with new keyword in C#. https://www.educative.io/answers/how-to-create-instances-of-a-class-with-new-keyword-in-c-sharp (Accessed 16 April 2024)
//GfG. (2019, November 19). C#: Arrays of strings. C# | Arrays of Strings. https://www.geeksforgeeks.org/c-sharp-arrays-of-strings/ (Accessed 16 April 2024)
//stackoverflow. (1957, April 1). How to clear all data / string in a textbox in C#. https://stackoverflow.com/questions/6479049/how-to-clear-all-data-string-in-a-textbox-in-c-sharp (Accessed 16 April 2024)
//stackoverflow. (2020, February 1). C#: Casting “0” to int. https://stackoverflow.com/questions/16456507/c-casting-0-to-int (Accessed 16 April 2024)
// Cheqq. (2023, June 1).Question: Part 2 - advanced C# features (Marks: 100) learning units 1 to 3 at the end of this specific part, students should be able to: • use a generic collection to solve a programming problem. • use delegates to solve a programming problem. you will continue working on the application created in part 1. implement the feedback provided by your lecturer on part 1. Solved Part 2 - Advanced C# Features (Marks: 100) Learning | Chegg.com. https://www.chegg.com/homework-help/questions-and-answers/part-2-advanced-c-features-marks-100-learning-units-1-3-end-specific-part-students-able-us-q115702867 (Accessed 16 May 2024)
//stackoverflow. (2020, December 1).How to assign 0 to whole array. https://stackoverflow.com/questions/22218066/how-to-assign-0-to-whole-array (Accessed 16 April 2024)