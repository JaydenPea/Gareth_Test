﻿namespace GarethEliePart1
{
    // Class to manage multiple recipes
    class RecipeBook
    {
        // List to store recipes
        //(stackoverflow, 2020)
        private List<Recipe> recipes;

        // Event to notify about high-calorie recipes
        public event Action<string> HighCalorieWarning;

        // Constructor to initialize the list of recipes
        public RecipeBook()
        {
            recipes = new List<Recipe>();
        }

        // Method to input a new recipe
        public void InputRecipe()
        //(stackoverflow, 2020)
        {
            // Create a new recipe
            Recipe newRecipe = new Recipe();

            // Subscribe to the high-calorie warning event
            newRecipe.HighCalorieWarning += (message) => HighCalorieWarning?.Invoke(message);

            // Input recipe details
            newRecipe.InputDetails();

            // Add the new recipe to the list
            recipes.Add(newRecipe);
        }

        // Method to display a specific recipe
        public void ShowRecipe()
        {
            // Display the list of recipes
            ListRecipes();

            // Prompt the user to select a recipe
            Console.WriteLine("Enter the name of the recipe to display:");
            string recipeName = Console.ReadLine();

            // Find the recipe by name
            Recipe recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

            //(stackoverflow, 2020)
            if (recipe != null)
            {
                recipe.ShowDetails();
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        // Method to scale a specific recipe
        public void ScaleRecipe()
        {
            // Display the list of recipes
            ListRecipes();

            // Prompt the user to select a recipe
            Console.WriteLine("Enter the name of the recipe to scale:");
            string recipeName = Console.ReadLine();

            // Find the recipe by name
            Recipe recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

            if (recipe != null)
            {
                recipe.ScaleRecipe();
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        // Method to reset quantities of a specific recipe
        public void ResetQuantities()
        {
            // Display the list of recipes
            ListRecipes();

            // Prompt the user to select a recipe
            Console.WriteLine("Enter the name of the recipe to reset quantities:");
            string recipeName = Console.ReadLine();

            // Find the recipe by name
            Recipe recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

            if (recipe != null)
            {
                recipe.ResetQuantities();
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        // Method to remove all recipes
        //(stackoverflow, 2020)
        public void RemoveAllInfo()
        {
            recipes.Clear();
            Console.WriteLine("All recipes cleared.");
        }

        // Method to list all recipes
        public void ListRecipes()
        {
            if (recipes.Count > 0)
            {
                // Sort recipes by name alphabetically
                //(stackoverflow, 2020)
                var sortedRecipes = recipes.OrderBy(r => r.Name).ToList();

                // Display sorted recipes
                Console.WriteLine("Recipes:");
                foreach (var recipe in sortedRecipes)
                {
                    Console.WriteLine(recipe.Name);
                }
            }
            else
            {
                Console.WriteLine("No recipes available.");
            }
        }
        // Method to filter recipes by ingredient, food group, or calories
        public void FilterRecipes()
        {
            Console.WriteLine("Enter an ingredient name to filter by (or leave empty):");
            string ingredientName = Console.ReadLine();

            Console.WriteLine("Enter a food group to filter by (or leave empty):");
            string foodGroup = Console.ReadLine();

            Console.WriteLine("Enter a maximum number of calories to filter by (or leave empty):");
            double maxCalories;
            double.TryParse(Console.ReadLine(), out maxCalories);

            var filteredRecipes = recipes.Where(r => r.MatchesCriteria(ingredientName, foodGroup, maxCalories)).ToList();

            if (filteredRecipes.Count > 0)
            {
                Console.WriteLine("Filtered Recipes:");
                foreach (var recipe in filteredRecipes)
                {
                    Console.WriteLine(recipe.Name);
                }
            }
            else
            {
                Console.WriteLine("No recipes matched the criteria.");
            }
        }

        // Method to create a menu and show food group distribution
        public void CreateMenuAndShowDistribution()
        {
            ListRecipes();

            List<Recipe> selectedRecipes = new List<Recipe>();

            Console.WriteLine("Enter the names of the recipes to include in the menu (comma-separated):");
            string input = Console.ReadLine();
            string[] recipeNames = input.Split(',');

            foreach (string recipeName in recipeNames)
            {
                Recipe recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName.Trim(), StringComparison.OrdinalIgnoreCase));
                if (recipe != null)
                {
                    selectedRecipes.Add(recipe);
                }
                else
                {
                    Console.WriteLine($"Recipe '{recipeName}' not found.");
                }
            }

            if (selectedRecipes.Count > 0)
            {
                Dictionary<string, double> totalFoodGroups = new Dictionary<string, double>();

                foreach (var recipe in selectedRecipes)
                {
                    var foodGroupQuantities = recipe.GetFoodGroupQuantities();
                    foreach (var kvp in foodGroupQuantities)
                    {
                        if (totalFoodGroups.ContainsKey(kvp.Key))
                        {
                            totalFoodGroups[kvp.Key] += kvp.Value;
                        }
                        else
                        {
                            totalFoodGroups[kvp.Key] = kvp.Value;
                        }
                    }
                }

                Console.WriteLine("Food Group Distribution:");
                double totalQuantity = totalFoodGroups.Values.Sum();
                foreach (var kvp in totalFoodGroups)
                {
                    double percentage = (kvp.Value / totalQuantity) * 100;
                    Console.WriteLine($"{kvp.Key}: {percentage:F2}%");
                }
            }
            else
            {
                Console.WriteLine("No valid recipes selected for the menu.");
            }
        }
    }
}