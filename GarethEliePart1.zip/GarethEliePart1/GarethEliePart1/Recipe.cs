﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarethEliePart1
{
    // Class to represent a recipe
    public class Recipe
    {
        // List to store ingredients
        //(geeksforgeeks, 2019)

        private List<Ingredient> ingredientList;

        // List to store instruction steps
        private List<string> instructionSteps;
        // Array to store original quantities of ingredients
        private double[] originalQuantities;

        // Property to store the recipe name
        public string Name { get; private set; }

        // Event to notify about high-calorie recipes
        public event Action<string> HighCalorieWarning;

        // Constructor to initialize lists
        //(stackoverflow, 2020)
        public Recipe()
        {
            ingredientList = new List<Ingredient>();
            instructionSteps = new List<string>();
        }

        public double CalculateTotalCalories()
        {
            return ingredientList.Sum(i => i.Calories);
        }

        public void AddIngredient(Ingredient ingredient)
        {
            ingredientList.Add(ingredient);

        }

        // Method to enter recipe details
        public void InputDetails()
        {
            try
            {
                // Prompt user for recipe name
                Console.WriteLine("Enter the recipe name:");
                Name = Console.ReadLine();

                // Prompt user for number of ingredients
                Console.WriteLine("Enter the number of ingredients:");
                int numIngredients = Convert.ToInt32(Console.ReadLine());

                // Loop to input ingredients and their details
                //(stackoverflow, 2020)
                for (int i = 0; i < numIngredients; i++)
                {
                    Console.WriteLine($"Enter name of ingredient {i + 1}:");
                    string name = Console.ReadLine();

                    Console.WriteLine($"Enter quantity of ingredient {i + 1}:");
                    double quantity = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine($"Enter unit of measurement for ingredient {i + 1}:");
                    string unit = Console.ReadLine();

                    Console.WriteLine($"Enter number of calories for ingredient {i + 1}:");
                    double calories = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine($"Enter food group for ingredient {i + 1}:");
                    string foodGroup = Console.ReadLine();

                    // Add ingredient to the list
                    ingredientList.Add(new Ingredient(name, quantity, unit, calories, foodGroup));
                }

                // Save original quantities for resetting later
                //(stackoverflow, 2020)
                originalQuantities = ingredientList.Select(i => i.Quantity).ToArray();

                // Prompt user for number of steps
                Console.WriteLine("Enter the number of steps:");
                int numSteps = Convert.ToInt32(Console.ReadLine());

                // Loop to input recipe steps
                for (int i = 0; i < numSteps; i++)
                {
                    //(stackoverflow, 2020)
                    Console.WriteLine($"Enter step {i + 1}:");
                    instructionSteps.Add(Console.ReadLine());
                }

                Console.WriteLine("Recipe details entered successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        // Method to display recipe details
        public void ShowDetails()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");

            // Display ingredients
            foreach (var ingredient in ingredientList)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})");
            }

            Console.WriteLine("Steps:");

            // Display steps
            for (int i = 0; i < instructionSteps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {instructionSteps[i]}");
            }

            // Calculate total calories
            double totalCalories = ingredientList.Sum(i => i.Calories);
            Console.WriteLine($"Total calories: {totalCalories}");

            // Trigger the event if total calories exceed 300
            if (totalCalories > 300)
            {
                HighCalorieWarning?.Invoke($"Warning: The total calories of the recipe '{Name}' exceed 300.");
            }
        }

        // Method to scale recipe quantities
        public void ScaleRecipe()
        {
            try
            {
                // Prompt user for scaling factor
                Console.WriteLine("Enter scaling factor (0.5 for half, 2 for double, 3 for triple):");
                double factor = Convert.ToDouble(Console.ReadLine());

                // Scale ingredient quantities
                foreach (var ingredient in ingredientList)
                {
                    //(stackoverflow, 2020)
                    ingredient.Quantity *= factor;
                }

                Console.WriteLine("Recipe scaled successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        // Method to reset ingredient quantities to original values
        public void ResetQuantities()
        {
            //(stackoverflow, 2020)
            for (int i = 0; i < ingredientList.Count; i++)
            {
                ingredientList[i].Quantity = originalQuantities[i];
            }
            Console.WriteLine("Quantities reset to original values.");
        }

        // Method to filter recipes by ingredient name, food group, or maximum calories
        public bool MatchesCriteria(string ingredientName, string foodGroup, double maxCalories)
        {
            bool matches = true;

            if (!string.IsNullOrEmpty(ingredientName))
            {
                matches &= ingredientList.Any(i => i.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase));
            }

            if (!string.IsNullOrEmpty(foodGroup))
            {
                matches &= ingredientList.Any(i => i.FoodGroup.Equals(foodGroup, StringComparison.OrdinalIgnoreCase));
            }

            if (maxCalories > 0)
            {
                matches &= CalculateTotalCalories() <= maxCalories;
            }

            return matches;
        }

        // Method to get the list of food groups and their quantities
        public Dictionary<string, double> GetFoodGroupQuantities()
        {
            Dictionary<string, double> foodGroupQuantities = new Dictionary<string, double>();

            foreach (var ingredient in ingredientList)
            {
                if (foodGroupQuantities.ContainsKey(ingredient.FoodGroup))
                {
                    foodGroupQuantities[ingredient.FoodGroup] += ingredient.Quantity;
                }
                else
                {
                    foodGroupQuantities[ingredient.FoodGroup] = ingredient.Quantity;
                }
            }

            return foodGroupQuantities;
        }
    }
}